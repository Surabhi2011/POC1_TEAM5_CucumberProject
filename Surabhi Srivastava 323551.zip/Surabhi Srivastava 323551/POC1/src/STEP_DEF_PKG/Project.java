package STEP_DEF_PKG;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
public class Project{
	WebDriver dr;	
	Logger log;
	WebDriverWait wt;
	@Given("^Browser islaunched & DemoWebShop homepage is displayed$")
	public void browser_islaunched_DemoWebShop_homepage_is_displayed() throws Throwable {
		 System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
	     dr = new ChromeDriver();
		 dr.get("http://demowebshop.tricentis.com/");
		 log=Logger.getLogger("devpinoyLogger");
		 log.info("Browser is launched & DemoWebShop home page is displayed");
	}
	@When("^Perform login valid$")
	public void perform_login_valid() throws Throwable {
      wt = new WebDriverWait(dr, 10);
	  dr.findElement(By.xpath("//a[@href='/login']")).click();
	  wt.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@value='Log in']")));
      dr.findElement(By.xpath("//input[@id='Email']")).sendKeys("surabhi12@gmail.com");
	  dr.findElement(By.xpath("//input[@id='Password']")).sendKeys("qwertyu");
	  dr.findElement(By.xpath("//input[@value='Log in']")).click();
	  log=Logger.getLogger("devpinoyLogger");
	  log.info("Login performed");
	}
	@When("^Perform login invalid$")
	public void perform_login_invalid() throws Throwable {
	  wt = new WebDriverWait(dr, 10);
	  dr.findElement(By.xpath("//a[@href='/login']")).click();
	  wt.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@value='Log in']")));
	  dr.findElement(By.xpath("//input[@id='Email']")).sendKeys("surabhi@gmail.com");
	  dr.findElement(By.xpath("//input[@id='Password']")).sendKeys("qwertyu");
	  dr.findElement(By.xpath("//input[@value='Log in']")).click();
	  log=Logger.getLogger("devpinoyLogger");
	  log.info("Login not performed");
	}	
	@Then("^Verify Successful login$")
	public void verify_Successful_login() throws Throwable {
	   String expected="surabhi12@gmail.com";
	   String actual=dr.findElement(By.xpath("//a[@href='/customer/info']")).getText();
	   Assert.assertEquals(expected, actual);
	   System.out.println("Successful login case : Pass");
	   log=Logger.getLogger("devpinoyLogger");
	   log.info("\nTest Case : Verify Successful login \nExpected Result : "+expected+"  \nActual Result : "+actual+" \nTest_Result : Pass");
	   dr.close();
	}
	@Then("^Verify Unsuccessful login$")
	public void verify_Unsuccessful_login() throws Throwable {
		String expected,actual;
	   expected="Login was unsuccessful. Please correct the errors and try again.\n" + 
	   		"The credentials provided are incorrect";
	   actual=dr.findElement(By.xpath("//*[@class='validation-summary-errors']")).getText();
	   Assert.assertEquals(expected, actual);
	   System.out.println("Unsuccessful login case : Pass");
	   log=Logger.getLogger("devpinoyLogger");
	   log.info("\nTest Case : Verify Unsuccessful login\nExpected Result : "+expected+"  \nActual Result : "+actual+"\nTest_Result : Pass");
	   dr.close();
	}
}